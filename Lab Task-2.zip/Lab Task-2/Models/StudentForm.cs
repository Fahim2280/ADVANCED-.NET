﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace Lab_Task_2.Models
{
    public class StudentForm
    {
        [Required]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Name should contain 3 t0 30 characters")]
        public string Name { get; set; }

        [Required]
        [RegularExpression(@"^\d\d-\d\d\d\d\d-\d$", ErrorMessage = "")]
        public int ID { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]
        [RegularExpression(@"[]+@student.aiub.edu", ErrorMessage = "")]
        public string Email { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 8)]
        public string Password { get; set; }

        [Compare("Password")]
        public string ConfPassword { get; set; }

        [Required]
        public string Dob { get; set; }


    }
}